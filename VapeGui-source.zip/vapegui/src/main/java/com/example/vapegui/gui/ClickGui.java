package com.example.vapegui.gui;

import com.example.vapegui.module.Category;
import com.example.vapegui.module.Module;
import com.example.vapegui.module.ModuleManager;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ClickGui extends GuiScreen {
    static final int W = 96, HEAD = 18, ROW = 16;
    static final int C_HEAD = 0xFF121212, C_BG = 0xE61C1C1C, C_ON = 0xFF0E8A6B,
            C_HOVER = 0x22FFFFFF, C_TEXT = 0xFFD8D8D8, C_DIM = 0xFF8A8A8A;

    private final List<Panel> panels = new ArrayList<Panel>();

    public ClickGui() {
        int x = 12;
        for (Category c : Category.values()) {
            panels.add(new Panel(c, x, 20));
            x += W + 8;
        }
    }

    @Override
    public void drawScreen(int mx, int my, float pt) {
        drawRect(0, 0, width, height, 0x55000000);
        for (Panel p : panels) p.draw(fontRendererObj, mx, my);
        super.drawScreen(mx, my, pt);
    }

    @Override
    protected void mouseClicked(int mx, int my, int btn) throws IOException {
        for (int i = panels.size() - 1; i >= 0; i--) { // topmost first
            Panel p = panels.get(i);
            if (p.click(mx, my, btn)) {
                panels.remove(i);
                panels.add(p); // bring to front
                return;
            }
        }
        super.mouseClicked(mx, my, btn);
    }

    @Override
    protected void mouseReleased(int mx, int my, int state) {
        for (Panel p : panels) p.dragging = false;
        super.mouseReleased(mx, my, state);
    }

    @Override
    public boolean doesGuiPauseGame() { return false; }

    static class Panel {
        final Category cat;
        final List<Module> mods;
        int x, y, dx, dy;
        boolean open = true, dragging;

        Panel(Category cat, int x, int y) {
            this.cat = cat; this.x = x; this.y = y;
            this.mods = ModuleManager.byCategory(cat);
        }

        void draw(FontRenderer fr, int mx, int my) {
            if (dragging) { x = mx - dx; y = my - dy; }
            Gui.drawRect(x, y, x + W, y + HEAD, C_HEAD);
            fr.drawStringWithShadow(cat.label, x + 6, y + 5, 0xFFFFFFFF);
            fr.drawStringWithShadow(open ? "-" : "+", x + W - 10, y + 5, C_DIM);
            if (!open) return;
            int ry = y + HEAD;
            for (Module m : mods) {
                boolean hover = mx >= x && mx < x + W && my >= ry && my < ry + ROW;
                Gui.drawRect(x, ry, x + W, ry + ROW, m.isEnabled() ? C_ON : C_BG);
                if (hover) Gui.drawRect(x, ry, x + W, ry + ROW, C_HOVER);
                fr.drawStringWithShadow(m.getName(), x + 6, ry + 4, m.isEnabled() ? 0xFFFFFFFF : C_TEXT);
                ry += ROW;
            }
        }

        boolean click(int mx, int my, int btn) {
            if (mx < x || mx >= x + W) return false;
            if (my >= y && my < y + HEAD) {
                if (btn == 0) { dragging = true; dx = mx - x; dy = my - y; }
                else if (btn == 1) open = !open;
                return true;
            }
            if (!open) return false;
            int idx = (my - y - HEAD) / ROW;
            if (my >= y + HEAD && idx >= 0 && idx < mods.size()) {
                if (btn == 0) mods.get(idx).toggle();
                return true;
            }
            return false;
        }
    }
}
