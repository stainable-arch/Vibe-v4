package com.example.vapegui;

import com.example.vapegui.gui.ClickGui;
import com.example.vapegui.module.Module;
import com.example.vapegui.module.ModuleManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Mod(modid = "vapegui", name = "VapeGui", version = "1.0", clientSideOnly = true, acceptedMinecraftVersions = "[1.8.9]")
public class VapeMod {
    public static final Minecraft mc = Minecraft.getMinecraft();
    private KeyBinding openKey;
    private ClickGui gui;

    @Mod.EventHandler
    public void init(FMLInitializationEvent e) {
        ModuleManager.init();
        openKey = new KeyBinding("Open ClickGUI", Keyboard.KEY_RSHIFT, "VapeGui");
        ClientRegistry.registerKeyBinding(openKey);
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onKey(InputEvent.KeyInputEvent e) {
        if (openKey.isPressed()) {
            if (gui == null) gui = new ClickGui();
            mc.displayGuiScreen(gui);
        }
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END || mc.thePlayer == null) return;
        for (Module m : ModuleManager.all()) if (m.isEnabled()) m.onTick();
    }

    /** Right-aligned list of enabled modules ("Text GUI"). */
    @SubscribeEvent
    public void onOverlay(RenderGameOverlayEvent.Text e) {
        List<Module> on = new ArrayList<Module>();
        for (Module m : ModuleManager.all()) if (m.isEnabled()) on.add(m);
        Collections.sort(on, (a, b) -> mc.fontRendererObj.getStringWidth(b.getName())
                - mc.fontRendererObj.getStringWidth(a.getName()));
        int w = e.resolution.getScaledWidth();
        int y = 2;
        for (Module m : on) {
            int sw = mc.fontRendererObj.getStringWidth(m.getName());
            mc.fontRendererObj.drawStringWithShadow(m.getName(), w - sw - 3, y, 0xFF1FD6A4);
            y += 10;
        }
    }
}
