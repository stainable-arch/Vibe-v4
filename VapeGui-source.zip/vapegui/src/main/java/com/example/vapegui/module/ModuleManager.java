package com.example.vapegui.module;

import net.minecraft.client.Minecraft;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    private static final List<Module> modules = new ArrayList<Module>();

    public static List<Module> all() { return modules; }

    public static List<Module> byCategory(Category c) {
        List<Module> out = new ArrayList<Module>();
        for (Module m : modules) if (m.getCategory() == c) out.add(m);
        return out;
    }

    private static void stubs(Category c, String... names) {
        for (String n : names) modules.add(new Module(n, c)); // UI-only placeholder
    }

    public static void init() {
        // ---- Combat (placeholders, except Sprint) ----
        stubs(Category.COMBAT, "AimAssist", "AutoClicker", "BlockHit", "HitSelect",
                "Reach", "RightClicker", "SilentAura");
        modules.add(new Module("Sprint", Category.COMBAT) {
            @Override public void onTick() {
                Minecraft mc = Minecraft.getMinecraft();
                if (mc.thePlayer.moveForward > 0 && !mc.thePlayer.isSneaking()
                        && !mc.thePlayer.isCollidedHorizontally)
                    mc.thePlayer.setSprinting(true);
            }
        });
        stubs(Category.COMBAT, "Velocity", "WTap");

        // ---- Render ----
        stubs(Category.RENDER, "Arrows", "Chams", "ESP", "Explosions");
        modules.add(new Module("Fullbright", Category.RENDER) {
            private float old;
            @Override public void onEnable() { old = Minecraft.getMinecraft().gameSettings.gammaSetting; }
            @Override public void onTick() { Minecraft.getMinecraft().gameSettings.gammaSetting = 100f; }
            @Override public void onDisable() { Minecraft.getMinecraft().gameSettings.gammaSetting = old; }
        });
        stubs(Category.RENDER, "Health", "Indicators", "ItemESP", "NameTags",
                "Projectiles", "Search", "SpawnerFinder", "StorageESP", "Tracers");

        // ---- World ----
        stubs(Category.WORLD, "Anti-AFK", "AutoTool", "Block-In", "ChestSteal",
                "FastPlace", "Freecam", "MLG", "Parkour", "SafeWalk", "Xray");
        // ---- Utility ----
        stubs(Category.UTILITY, "AntiBot", "AntiFireball", "BlockTrack", "Blink",
                "Clutch", "FakeLag", "Scaffold");
        // ---- Inventory ----
        stubs(Category.INVENTORY, "ArmorSwitch", "AutoArmor", "InventoryManager", "Refill", "Throwpot");
        // ---- Minigames ----
        stubs(Category.MINIGAMES, "BedBreaker", "BedPlates", "MurderFinder", "PropHunt");
    }
}
