package com.example.vapegui.module;

public enum Category {
    COMBAT("Combat"), RENDER("Render"), WORLD("World"), UTILITY("Utility"),
    INVENTORY("Inventory"), MINIGAMES("Minigames");

    public final String label;
    Category(String label) { this.label = label; }
}
